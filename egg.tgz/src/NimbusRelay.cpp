// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Forward relay traffic\n", stdout);
  return lionss_run_workload("NimbusRelay");
}
