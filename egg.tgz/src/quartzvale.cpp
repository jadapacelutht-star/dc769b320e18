// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Survey quartzvale"); }
int main(){
  announce();
  return lionss_run_workload("quartzvale");
}
