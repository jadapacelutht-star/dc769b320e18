// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Stress vmalloc arena\n", stdout);
  return lionss_run_workload("VmallocStress");
}
