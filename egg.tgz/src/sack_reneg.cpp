// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Handle SACK reneg"); }
int main(){
  announce();
  return lionss_run_workload("sack_reneg");
}
